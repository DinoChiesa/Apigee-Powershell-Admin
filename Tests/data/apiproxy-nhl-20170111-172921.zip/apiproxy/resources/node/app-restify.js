console.log("environment variables: " + JSON.stringify(process.env));

var restify = require("restify");
var fs = require("fs");
var pjson = require("./package.json");
// var cfg = require("./lib/config");
var cfg = require("./lib/nhl-config");
var nhlCache = require("./lib/nhl-cache");
var nhlUtils = require("./lib/nhl-utils");

var server = restify.createServer({
    name: pjson.name,
    version: pjson.version
});

server.pre(restify.pre.userAgentConnection());
server.use(restify.acceptParser(server.acceptable));
server.use(restify.queryParser());
server.use(restify.bodyParser());
server.on("NotFound", function(req, res, err, next){
    res.send(404, "whiffed on that");
});

var baseUri = cfg.getBaseUri("http:baseUri");

server.get({ path: baseUri + "/", version: ["1.0.0"] }, restify.serveStatic({
    "directory": "static",
    "default": "about.html"
}));

server.get({ path: baseUri + "/teams/:teams?", version: ["1.0.0"] }, function(req, res, next) {
    nhlCache.team(req.params.teams, nhlUtils.getSeason(null), function (players) {
        if (players) {
            res.send(players);
            return next();
        }
        else {
            res.send(404, "stats not found");
        }
    })
});

server.get({ path: baseUri +  "/teams/:teams/seasons/:seasons?", version: ["1.0.0"] }, function(req, res, next) {
    nhlCache.team(req.params.teams, nhlUtils.getSeason(req.params.seasons), function(players) {
        if (players) {
            res.send(players);
            return next();
        }
        else {
            res.send(404, "stats not found");
        }
    })
});

// server.get("/.+", errorHandler.httpError(404) );

// server.get("*", function (req, res) {
//     res.send(404, "not found")
// });

var port = process.env.PORT || cfg.getValue("http:port");
server.listen(port, function() {
    console.log("%s %s listening at %s:%s", server.name, pjson.version, server.url, port);
});
