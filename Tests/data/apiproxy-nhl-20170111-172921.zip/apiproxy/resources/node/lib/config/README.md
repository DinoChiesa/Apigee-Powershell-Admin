# Notes

**IGNORE** this directory and content. Various commented out section reference this area. It is just a configuration experiment **NOT** using `nconf`.
