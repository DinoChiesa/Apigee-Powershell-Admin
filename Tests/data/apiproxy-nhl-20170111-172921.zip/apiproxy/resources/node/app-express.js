console.log("environment variables: " + JSON.stringify(process.env));

var express = require("express");
// var cfg = require("./lib/config");
var cfg = require("./lib/nhl-config");
var nhlCache = require("./lib/nhl-cache");
var nhlUtils = require("./lib/nhl-utils");

var app = express();

var baseUri = cfg.getBaseUri("http:baseUri");

app.get(baseUri + "/", function(req, res) {
    res.sendFile(__dirname + "/static/about.html");
});

app.get(baseUri + "/teams/:teams?", function(req, res) {
    nhlCache.team(req.params.teams, nhlUtils.getSeason(null), function(players) {
        if (players) {
            res.send(players);
        }
        else {
            res.status(404).send("stats not found");
        }
    })
});

app.get(baseUri + "/teams/:teams/seasons/:seasons?", function(req, res) {
    nhlCache.team(req.params.teams, nhlUtils.getSeason(req.params.seasons), function(players) {
        if (players) {
            res.send(players);
        }
        else {
            res.status(404).send("stats not found");
        }
    })
});

app.get("*", function(req, res) {
    res.status(404).send("whiffed on that")
});

// start the server
var port = process.env.PORT || cfg.getValue("http:port");
var listener = app.listen(port, function () {
    console.log("server listening at http://%s:%s", listener.address().address, listener.address().port);
});
