# NHL API for Apigee

**NOTE:** This is an on-going project/experiment within Apigee Edge, so you will see commented out code and other weirdness that is not normally seen in normal workflows.

## Setup

```javascript
npm install
```

## Package and Deploy to Apigee

**NOTE:** Replace `YOUR-ORG` with your organization.

```javascript
./node_modules/apigeetool/lib/cli.js deploynodeapp -n nhl_nodejs -d . -m app.js -o YOUR-ORG -e test -b /nhl/v1
```

## Usage 

Launch server

```javascript
node app.js
```

Get the current season stats

**NOTE:** URL paths are kind of messed up locally as the base path `/nhl/v1/` needs to be part of the Apigee setup, so when calling on Apigee remember to change the host and prepend `/nhl/v1` to the path.

```
format: http://localhost:7001/teams/:teams
example: http://localhost:7001/teams/sharks
```

Get a specific season, either format
* `YYYY`
* `YYYYYYYY`

```
format: http://localhost:7001/teams/:teams/seasons/:seasons
example: http://localhost:7001/teams/sharks/seasons/20152016
```

